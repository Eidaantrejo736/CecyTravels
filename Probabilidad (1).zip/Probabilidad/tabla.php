<html>
<head><title>paginaconnect</title></head><link href="style.css" rel="stylesheet" type="text/css">
    <body><center>
        
   <?php 
        
        
        $conn=mysqli_connect("localhost","root","")
            or die("variables incorrectas");
        
        echo"<img src='PicsArt_05-08-02.32.23.jpg'>";
        mysqli_select_db($conn,"Zapateria")
        or die ("Database no selected ");
        echo"</br>";
        echo"<h4>Estos son los productos en la tienda</h4></br> ";
        
        $sql = mysqli_query($conn,"select * from zapatos ");
        $res = mysqli_num_rows($sql);
        echo "<h4>Existen " .$res. "   registros</h4>";
        
    

        ?>
        <table border=1 ><tr> <td>Id</td>
            <td>Nombre</td>
            <td>Precio</td>
            <td>Stock</td>
            
           
            </tr>
        <?php 
        
            $sql="select * from zapatos";
            $res=mysqli_query($conn,$sql);
        while($mos=mysqli_fetch_array($res)){
            
       
        ?>
        <tr>
            <td><?php echo $mos["id_zapato"]?></td>
            <td><?php echo $mos["Nombre"]?></td>
            <td><?php echo $mos["Precio"]?></td>
            <td><?php echo $mos["Stock"]?></td>
            
            </tr>
        <?php      }
            ?>
            
            
            
        </table>
         
  <table border="0" align="center">
  
     
        </center>
    </body>
</html>