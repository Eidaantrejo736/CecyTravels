<html>
    <head>
    <title>ELIMINAR</title>
    </head>
      <link type="text/css" rel="stylesheet" href="cssparaformularios.css">
    <body>
        <CENTER>
            <h2> Ingresa el numero de registro que desea eliminar </h2>
    <form action="eliminar.php" method="POST">
        <p><input type="text" name="id" id="id" required></p>
        <input type="submit" name="hehe" value="Eliminar">
        </form>  
            </CENTER>
        <center>
  &nbsp; &nbsp;<a href="registro.php"><img src="icono1.png"></a>&nbsp; &nbsp;&nbsp; &nbsp;<a href="eliminar1.php"><img src="icono2.png"></a>&nbsp; &nbsp;&nbsp; <br><a href="update.php"><img src="icono3.png"></a>&nbsp; &nbsp;&nbsp; &nbsp;<a href="tabla.php"><img src="icono4.png"></a><a href="Principal.php"><br><img src="PicsArt_05-08-02.32.23.jpg"></a></center>
          </body>
</html>
