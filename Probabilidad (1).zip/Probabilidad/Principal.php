
<html>
<head>
  <link rel="stylesheet" href="styles/style.css"/>
  
  
  <title>Zapateria Jimenez</title>
</head>
<body><center>
  <hr size="15" color="Royalblue">
  &nbsp; <img src="PicsArt_05-08-02.32.23.jpg"><h1>Zapater&iacute;a Jimenez</h1>Por Estudio Cecyrancho

  <br>&nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp;
  <br>
    <br>
  
  
  
  <hr size="15" color="Royalblue">
 
  <center><img src="Bienvenida.jpeg">
  
    <br>
    <h3> &iquest;Qu&eacute; acción deseas realizar?</h3></center>
  <br>
  <center>
  &nbsp; &nbsp;<a href="registro.php"><img src="icono1.png"></a>&nbsp; &nbsp;&nbsp; &nbsp;<a href="eliminar1.php"><img src="icono2.png"></a>&nbsp; &nbsp;&nbsp; <br><a href="update.php"><img src="icono3.png"></a>&nbsp; &nbsp;&nbsp; &nbsp;<a href="tabla.php"><img src="icono4.png"></a></center>
  <hr size="15" color="Royalblue">

  <br>
  <h3>Env&iacute;os y atenci&oacute;n al cliente</h3>
  
  <br>
  <br><strong>Haz click para ingresar a los pedidos de mercado libre.</strong><br>
  
  <center><a href="https://www.mercadolibre.com.mx/"><img src="MercadoLibreimagen.jpg"></a></center>
  <br>
  <br>
  <center> <img src="PicsArt_05-08-03.18.20.jpg">  
  </center>
  <h4>Acceder a redes sociales de la tienda</h4>
  
  
  <center><a href="https://m.facebook.com" ><img src="PicsArt_05-08-12.29.50.jpg"></a>&nbsp; &nbsp; 
  <a href="https://www.instagram.com/ed_tr30/" ><img src="PicsArt_05-08-12.32.15.jpg"></a></center>
</center></body>
</html>
