<html><link type="text/css" rel="stylesheet" href="cssparadatos.css">
<head>
    <meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
    
    <title>registro</title>
    </head>
    <body>
<div align="center">
<h1>Bienvenido</h1>            <img src="PicsArt_05-08-02.32.23.jpg">
<h1>Ingresa los datos del inventario</h1>
<form id="form1" name="form1" method="post" action="">
<table width="333" border="0">
<tr>
<td width="156" height="43"><h2>Nombre</h2></td> 
<td width="161"><input type="text" name="nombre" /></td>
</tr>
    <tr>
     <td height="45"><h2>Precio</h2></td> 
    <td><input type="text" name="paterno" />
        </td>
        </tr>
 
    <tr>
     <td height="51"><h2>Stock</h2></td> 
    <td><input type="text" name="telefono" />
        </td>
    </tr>
</table>
     <br>
    <br>
    <br>
         <p>
    <label></label> <label></label> <label></label> <label></label> <label></label> <label></label>
    </p>   
    <p>
     <label></label><label><input type="submit"
    name="register" value="Enviar"/></label></p>
            
            </form>
        </div>
        <?php
        include("insertar.php")
            ?>
    </body>
</html>