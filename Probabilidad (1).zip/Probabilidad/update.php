<html><link type="text/css" rel="stylesheet" href="cssparaformularios.css">
<head>
    <meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
    
    <title>registro</title>
    </head>
    <body>
<div align="center">
<h1>Bienvenido</h1>            <img src="PicsArt_05-08-02.32.23.jpg">
<h1>Ingresa los datos que deseas actualizar</h1><center>
<form id="form1" name="form1" method="POST" action="actualiza.php">
<table width="800" border="0">
     <tr>
     <td height="45"><h2>Id</h2></td> 
    <td><input type="text" name="cod" required />
        </td>
        </tr> 
<tr>
<td width="100" height="100"><h2>Nombre</h2></td> 
    <br>
      <br>
<td width="100"><input type="text" name="nombre" required  /></td>
</tr>  <br>  <br>
    <tr>
     <td height="45"><h2>Precio</h2></td> 
    <td><input type="text" name="precio" required />
        </td>
        </tr>  <br>  <br>
 
    <tr>
     <td height="40"><h2>Stock</h2></td> 
    <td><input type="text" name="stock" required />
        </td>
    </tr>
</table>
     <br>
    <br>
    <br>
         <p>
    <label></label> <label></label> <label></label> <label></label> <label></label> <label></label>
    </p>   
    <p>
     <label></label><label><input type="submit"
    name="register" value="Enviar"/></label></p>
            
            </form></center>
        </div>
        <center>
  &nbsp; &nbsp;<a href="registro.php"><img src="icono1.png"></a>&nbsp; &nbsp;&nbsp; &nbsp;<a href="eliminar1.php"><img src="icono2.png"></a>&nbsp; &nbsp;&nbsp; <br><a href="update.php"><img src="icono3.png"></a>&nbsp; &nbsp;&nbsp; &nbsp;<a href="tabla.php"><img src="icono4.png"></a><a href="Principal.php"><br><img src="PicsArt_05-08-02.32.23.jpg"></a></center>
        
    </body>
</html>