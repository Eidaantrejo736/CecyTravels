<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<title>Login</title></head>
<body>
<div>
<center>
<form method="POST" action="register.php">
<input type="text" name="nnombre" placeholder="Usuario" />
<br />
<input type="password" name="npassword" placeholder="Contraseña" />
<br />
<button type="submit">Inicar Sesion</button>
</form>
</center>
</div>
</body>
</html>