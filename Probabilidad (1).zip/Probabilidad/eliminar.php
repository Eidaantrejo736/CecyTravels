<html>
<head>
    <title>hehehehe</title><link rel="stylesheet" href="styles/style.css"/>
    </head>
    <body>
<center>
    <?php
        $dni=$_POST['id'];
       
         $conn=mysqli_connect("localhost","root","");
       
        mysqli_select_db($conn,"Zapateria");
       
        $sqlo="delete from Zapatos where Id_zapato=$dni;";
             
       
mysqli_query($conn,$sqlo);
       echo "<h4>Se ha eliminado el registro del producto correctamente</h4>";
        ?>

         <?php 
        
        
        $conn=mysqli_connect("localhost","root","")
            or die("variables incorrectas");
        
        echo"<img src='PicsArt_05-08-02.32.23.jpg'>";
        mysqli_select_db($conn,"Zapateria")
        or die ("Database no selected ");
        echo"</br>";
        
        
        $sql = mysqli_query($conn,"select * from zapatos ");
        $res = mysqli_num_rows($sql);
        echo "<h4>Existen " .$res. "   registros</h4>";
        
    

        ?>
        <table border=1 ><tr> <td>Id</td>
            <td>Nombre</td>
            <td>Precio</td>
            <td>Stock</td>
            
           
            </tr>
        <?php 
        
            $sql="select * from zapatos";
            $res=mysqli_query($conn,$sql);
        while($mos=mysqli_fetch_array($res)){
            
       
        ?>
        <tr>
            <td><?php echo $mos["id_zapato"]?></td>
            <td><?php echo $mos["Nombre"]?></td>
            <td><?php echo $mos["Precio"]?></td>
            <td><?php echo $mos["Stock"]?></td>
            
            </tr>
        <?php      }
            ?>
            
            
            
        </table>
         
  
        </center>

  
     
    </body>
</html>


