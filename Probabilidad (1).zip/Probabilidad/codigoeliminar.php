<html>
    <head>
    <title>Cafeteria</title>
    </head>
    <LINK REL="STYLESHEET" TYPE="TEXT/CSS" HREF="yo.css"/>
    <body background="cafe.png">
        <CENTER>
            <h1> <font color="green"> Ingresa el numero de registro que desea eliminar </font> </h1>
    <form action="codigoeliminar.php" method="post">
        <p>ID<input type="text" name="id" id="id"></p>
        <input type="submit" name="hehe" value="Eliminar">
        </form>  
            </CENTER>
          </body>
</html>
