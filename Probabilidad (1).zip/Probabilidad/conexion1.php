
<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
    
    <title>> Documento sin t&iacute;tulo</title>
    </head>
    <body>
<div align="center">
<p>bienvenido</p>            
<p>completa el siguiente formulario</p>
<form id="form1" name="form1" method="post" action="">
<table width="333" border="0">
<tr>
<td width="156" height="43">Nombre</td> 
<td width="161"><input type="text" name="nombre" /></td>
</tr>
    <tr>
     <td height="45">apellido paterno</td> 
    <td><input type="text" name="paterno" />
        </td>
        </tr>
    <tr>
     <td height="44">apellido meterno</td> 
    <td><input type="text" name="materno" />
        </td>
        </tr>
    <tr>
     <td height="39">estado</td> 
    <td><input type="text" name="estado" />
        </td>
        </tr>
    <tr>
     <td height="48">municipio</td> 
    <td><input type="text" name="municipio" />
        </td>
        </tr>
    
                <tr>
     <td height="38">e-mail</td> 
    <td><input type="text" name="email" />
        </td>
        </tr>
    <tr>
     <td height="51">telefono</td> 
    <td><input type="text" name="telefono" />
        </td>
    </tr>
</table>
         <p>
    <label></label> <label></label> <label></label> <label></label> <label></label> <label></label>
    </p>   
    <p>
     <label></label><label><input type="submit"
    name="register" value="enviar"/></label></p>
            
            </form>
        </div>
        <?php
        include("registrar.php")
            ?>
    </body>
</html>
