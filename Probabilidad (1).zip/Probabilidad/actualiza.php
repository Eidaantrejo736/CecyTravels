<html>
<head></head><title>Actualizar</title><link rel="stylesheet" href="styles/style.css"/>
<body>
    <center>
<?php
$nombre=$_POST['nombre']; 
$desc=$_POST['precio']; 
$cantidad=$_POST['stock']; 
$id=$_POST['cod'];   
    
    
    
    
  
 
$conn=mysqli_connect("localhost","root","")
or die("Variables incorrectas");
echo('<h4>Muy bien</h4>');  
mysqli_select_db($conn,"Zapateria")
or die("Database not select");
echo"<br><h4>La informacion del producto fue actualizada de forma exitosa</h4>";
    

$sql="update Zapatos set Nombre='$nombre' where Id_zapato='$id'"; 
    $res = mysqli_query($conn,$sql);
    
    $sql="update Zapatos set Precio='$cantidad' where Id_zapato='$id'"; 
    $res = mysqli_query($conn,$sql);
    
    $sql="update Zapatos set Stock='$desc' where Id_zapato='$id'"; 
    $res = mysqli_query($conn,$sql);
   
$res = mysqli_query($conn,$sql);
    
?>
<?php 
        
        
        $conn=mysqli_connect("localhost","root","")
            or die("variables incorrectas");
        
        echo"<img src='PicsArt_05-08-02.32.23.jpg'>";
        mysqli_select_db($conn,"Zapateria")
        or die ("Database no selected ");
        echo"</br>";
        
        $sql = mysqli_query($conn,"select * from zapatos ");
        $res = mysqli_num_rows($sql);
        echo "<h4>Existen " .$res. "   registros</h4>";
        
    

        ?>
        <table border=1 ><tr> <td>Id</td>
            <td>Nombre</td>
            <td>Precio</td>
            <td>Stock</td>
            
           
            </tr>
        <?php 
        
            $sql="select * from zapatos";
            $res=mysqli_query($conn,$sql);
        while($mos=mysqli_fetch_array($res)){
            
       
        ?>
        <tr>
            <td><?php echo $mos["id_zapato"]?></td>
            <td><?php echo $mos["Nombre"]?></td>
            <td><?php echo $mos["Precio"]?></td>
            <td><?php echo $mos["Stock"]?></td>
            
            </tr>
        <?php      }
            ?>
            
            
            
        </table>
         
  <table border="0" align="center">
  
     
        </center>
    
    
    
    

</body>
</html>