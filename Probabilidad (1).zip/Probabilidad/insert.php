<?php
$host = "localhost";
$user = "root";
$pass="";
$db='proyecto_angel';

$con=mysqli_connect($host,$user,$pass,$db)or die("Problemas al conectar");
mysqli_select_db($con,$db)or die("Problemas al conectar con la base de datos");

$Nombre=$_POST['Nombre'];
$Apellido_P=$_POST['Apellido_P'];
$Apellido_M=$_POST['Apellido_M'];
$fecha_nacimiento=$_POST['fecha_nacimiento'];
$correo=$_POST['correo'];
$contrasena=$_POST['contrasena'];

$sql="INSERT INTO registro values('$Nombre','$Apellido_P','$Apellido_M','$fecha_nacimiento','$correo','$contrasena')";

$ejecutar=mysqli_query($con,$sql);
if(!$ejecutar){
header('Location: error.html');
}else{
header('Location: lo.html');
}
?>

<?php
$conex=mysqli_connect("localhost","root","","proyecto_angel")or die("no se conecto");
$usuario = $_POST['correo'];
$Cont = $_POST['contrasena'];
session_start();
$_SESSION['correo']= $usuario;


$Consulta= "SELECT * FROM user where Correo='$usuario' and Contrasenia='$Cont'";
$resultado= mysqli_query($conex,$Consulta);

$filas=  mysqli_num_rows($resultado);

if($filas){
    header("location:lo.html");
}else{
    ?>
    <?php
    include("registrar.html");
?><h1 class="bad">Error en la autentificación</h1>
    
<?php
}