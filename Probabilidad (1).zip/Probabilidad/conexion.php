<html>
<head><title>paginaconnect</title></head><link href="aaa.css" rel="stylesheet" type="text/css">
    <body><center>
        
   <?php 
        
        
        $conn=mysqli_connect("localhost","root","")
            or die("variables incorrectas");
        
        echo"Conexion establecida correctamente ";
        mysqli_select_db($conn,"cafeteria")
        or die ("Database no selected ");
        echo"</br>";
        echo"Base de datos seleccionada correctamente</br> ";
        
        $sql = mysqli_query($conn,"select * from producto ");
        $res = mysqli_num_rows($sql);
        echo "Existen " .$res. "   registros";
        
    

        ?>
        <table border=1 ><tr> <td>id</td>
            <td>nombre</td>
            <td>desc</td>
            <td>cant</td>
            <td>precio</td>
           
            </tr>
        <?php 
        
            $sql="select * from producto";
            $res=mysqli_query($conn,$sql);
        while($mos=mysqli_fetch_array($res)){
            
       
        ?>
        <tr>
            <td><?php echo $mos["Id_Producto"]?></td>
            <td><?php echo $mos["Nom_Producto"]?></td>
            <td><?php echo $mos["Des_Prod"]?></td>
            <td><?php echo $mos["Cantidad"]?></td>
            <td><?php echo $mos["Precio"]?></td>
            </tr>
        <?php      }
            ?>
            
            
            
        </table>
        <form action="update.php" method="POST">
  <table border="0" align="center">
  <tr>
      <tr>
      <td>
          codigo
      </td>
      <td>
      <input type="text" name="cod" required></td>
  </tr>

   <tr>
      <td>
          Nombre
      </td>
      <td>
      <input type="text" name="nom" ></td>
  </tr>
      <tr>
      <td>
          Descripcion
      </td>
      <td>
      <input type="text"name="desc" ></td>
  </tr>
   <tr>
      <td>
          Cantidad
      </td>
      <td>
      <input type="text" name="can" ></td>
  </tr>
      <tr><td>Precio
          </td>
      <td>
      <input type="text" name="pre" ></td>
  </tr>
     
   <tr>
      <td>
      <tr>
      <td align="center "> <input type="reset" name="Borrar" 
id="Borrar" value="Borrar" /></td>
      <td align="center"> <input type="submit" name="enviar" 
id="enviar" value="Actualizar" /></td>
          </tr></td>
  </table>
        </form>
        </center>
    </body>
</html>
